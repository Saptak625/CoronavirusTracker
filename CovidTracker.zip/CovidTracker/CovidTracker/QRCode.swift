//
//  QRCode.swift
//  CovidTracker
//
//  Created by Asrith Sreeram on 11/14/20.
//  Copyright © 2020 Asrith Sreeram. All rights reserved.
//

import Foundation
class QRCode{
    /*
    var code: Image
    
    init(_ image: Image){
        self.code=image
    }
    
    func scan() -> Location {
        return scan()
    }
 */
}
