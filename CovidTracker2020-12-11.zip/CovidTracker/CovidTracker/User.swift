//
//  User.swift
//  CovidTracker
//
//  Created by Asrith Sreeram on 11/14/20.
//  Copyright © 2020 Asrith Sreeram. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseFirestore

class User{
    //Default settings for new users
    var anon_uuid: String = "Hello World"
    var endLocationRequests: String = ""
    var enterLocation: Bool = false
    var locationsVisited: [Location] = []
    var notifications: [String] = ["Welcome to Covid Tracker!"]
    var riskAssesment: RiskValues = .green
    var status: InfectionStatus = .negative
    var timeStart: Timestamp = Timestamp(date: Date())
    
    init(_ uid: String){
        self.anon_uuid = uid
        print("First bruh", anon_uuid)
        //Check if new user or not.
        let db = Firestore.firestore()

        let docRef = db.collection("users").document(self.anon_uuid)

        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                //Document Exists
                print("Fetching User Variables...")
                if let data = document.data() {
                self.endLocationRequests = data["endLocationRequests"] as? String ?? ""
                self.enterLocation = data["enterLocation"] as? Bool ?? false
                self.locationsVisited = data["locationsVisited"] as? [Location] ?? []
                self.notifications = data["notifications"] as? [String] ?? []
                self.riskAssesment = data["riskAssesment"] as? RiskValues ?? .green
                self.status = data["status"] as? InfectionStatus ?? .negative
                self.timeStart = data["timeStart"] as? Timestamp ?? Timestamp(date: Date())
                } else {
                    print("Data could not be unpacked")
                    exit(0)
                }
            } else {
                //Document doesn't exist
                //Only add user to Firestore
                print("Creating new User Variables...")
                //Adding new Document to Firestore
                docRef.setData([
                    "anon_uuid": self.anon_uuid,
                    "endLocationRequests": self.endLocationRequests,
                    "enterLocation": self.enterLocation,
                    "locationsVisited": self.locationsVisited,
                    "notifications": self.notifications,
                    "riskAssesment": "green",
                    "status": "negative",
                    "timeStart": self.timeStart
                ]) { err in
                    if let err = err {
                        print("Error writing document: \(err)")
                    } else {
                        print("Document successfully written!")
                    }
                }
            }
        }
    }
    
    func evaluateRisk(){
        //Insert risk assesment algorithm
        if status == .positive{
            riskAssesment = .red
        }else{
            let numOfContactedPeople=getNumOfContactedInfections()
            if numOfContactedPeople<=1{
                riskAssesment = .green
            }else if numOfContactedPeople<=3{
                riskAssesment = .yellow
            }else{
                riskAssesment = .red
            }
        }
    }
    
    func checkInfection(){
        let numOfQuestions=3
        let symptoms=2
        let testConducted=true
        let testResult = InfectionStatus.negative
        status=(testConducted && testResult == .positive) || (Double(symptoms)/Double(numOfQuestions)>=0.4 || getNumOfContactedInfections()>=1) ? .positive : .negative
        print(status == .positive ? "You may have contacted Covid-19. We recommend that you quarantine for 8-12 days to save lives." : "You have most likely not contracted Covid-19. However, just to be sure, we recommend that you quarantine for 3-5 days to see if symptoms progress.")
        evaluateRisk()
    }
    
    func getNumOfContactedInfections() -> Int{
        //Would perform math of number of contacted people
        return 2
    }
    
    
  
}

