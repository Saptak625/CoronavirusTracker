//
//  Location.swift
//  CovidTracker
//
//  Created by Asrith Sreeram on 11/14/20.
//  Copyright © 2020 Asrith Sreeram. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class Location{
    var name: String
    var address: String
    var qrCode: QRCode
    var dateTime: [String: [User]]=[:]
    
    init(_ name: String, _ address: String) {
        //User creates QR
        self.name=name
        self.address=address
        self.qrCode=Location.generateQR(self.address)
        let db = Firestore.firestore()
        let docRef = db.collection("locations").whereField("address", isEqualTo: self.address)
            .getDocuments() { (querySnapshot, err) in
                if let err = err {
                    print("Error getting documents: \(err)")
                } else {
                    let data: [String:Any] = querySnapshot!.documents[0].data()
                    if !data.isEmpty {
                        //Document Exists
                        print("Fetching User Variables...")
                        self.name = data["name"] as? String ?? ""
                        self.address = data["address"] as? String ?? ""
                        let qrCodePath = data["QRCode"] as? String ?? ""
                        //Get QRCode from Storage
                        let storage = Storage.storage()
                        let imageRef = storage.reference(withPath: "QRCode/"+self.address.replacingOccurrences(of: ", ", with: "_", options: .literal, range: nil).replacingOccurrences(of: ",", with: "_", options: .literal, range: nil).replacingOccurrences(of: " ", with: "_", options: .literal, range: nil)+".jpg")
                        imageRef.getData(maxSize: 1 * 1024 * 1024) { data, error in
                            if let error = error {
                                print("ERROR: Image could not be downloaded.")
                            } else {
                                self.qrCode = QRCode(UIImage(data: data!)!)
                            }
                        }
                        
                    } else {
                        self.exportToFirebase()
                    }
                    
                }
                
        }

    }
    
    static func generateQR(_ address: String) -> QRCode {
        //Use QRCode Generator Code
        return QRCode(UIImage(imageLiteralResourceName: "basketball"))
    }

    func exportToFirebase() {
        let db = Firestore.firestore()
        let docRef=db.collection("locations").document()
        docRef.setData([
            "name": self.name,
            "address": self.address,
            //Possibly change file type definition
            "QRCode": "QRCode/"+self.address.replacingOccurrences(of: ", ", with: "_", options: .literal, range: nil).replacingOccurrences(of: ",", with: "_", options: .literal, range: nil).replacingOccurrences(of: " ", with: "_", options: .literal, range: nil)+".jpg"
        ]) { err in
            if let err = err {
                print("Error writing document: \(err)")
            } else {
                print("Document successfully written!")
            }
        }
        //Put qrCode in location
        let storage = Storage.storage()
        let imageRef = storage.reference(withPath: "QRCode/"+self.address.replacingOccurrences(of: ", ", with: "_", options: .literal, range: nil).replacingOccurrences(of: ",", with: "_", options: .literal, range: nil).replacingOccurrences(of: " ", with: "_", options: .literal, range: nil)+".jpg")
        // Upload the file to the path "images/rivers.jpg"
        let uploadTask = imageRef.putData(self.qrCode.code.jpegData(compressionQuality: 0.9)!, metadata: nil) { (metadata, error) in
          guard let metadata = metadata else {
            // Uh-oh, an error occurred!
            print("Image was not uploaded!")
            return
          }
          // Metadata contains file metadata such as size, content-type.
          let size = metadata.size
          // You can also access to download URL after upload.
          imageRef.downloadURL { (url, error) in
            guard let downloadURL = url else {
              // Uh-oh, an error occurred!
              print("Url was not valid!")
              return
            }
          }
        }
    }

    func getDateTime(){
        //Get subcollection data from Firestore. Replace all placeholders.
        self.dateTime=[:]
    }
}

