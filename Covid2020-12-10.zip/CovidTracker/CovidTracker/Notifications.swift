//
//  Notifications.swift
//  CovidTracker
//
//  Created by Asrith Sreeram on 11/14/20.
//  Copyright © 2020 Asrith Sreeram. All rights reserved.
//

import Foundation
class Notifications{
    let message: String
    
    init(_ message: String){
        self.message=message
    }
    
    func display(){
        //Formating for UI
    }
}
