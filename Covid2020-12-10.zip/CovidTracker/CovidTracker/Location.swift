//
//  Location.swift
//  CovidTracker
//
//  Created by Asrith Sreeram on 11/14/20.
//  Copyright © 2020 Asrith Sreeram. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore

class Location{
    var name: String
    var address: String
    var qrCode: QRCode
    var dateTime: [String: [User]]=[:]
    
    init(_ name: String, _ address: String) {
        //User creates QR
        self.name=name
        self.address=address
        self.qrCode=Location.generateQR(self.address)
        exportToFirebase()
    }

    init(_ name: String, _ address: String, _ image: UIImage) {
        //Get QR from Firebase
        self.name=name
        self.address=address
        self.qrCode=QRCode(image)
    }
    
    static func generateQR(_ address: String) -> QRCode {
        //Use QRCode Generator Code
        return QRCode(UIImage(imageLiteralResourceName: "basketball.jpg"))
    }

    func exportToFirebase() {
        let db = Firestore.firestore()
        let docRef=db.collection("locations").document()
        docRef.setData([
            "name": self.name,
            "address": self.address,
            //Possibly change file type definition
            "QRCode": "QRCode/"+self.address.replacingOccurrences(of: ", ", with: "_", options: .literal, range: nil).replacingOccurrences(of: ",", with: "_", options: .literal, range: nil).replacingOccurrences(of: " ", with: "_", options: .literal, range: nil)+".jpg"
        ]) { err in
            if let err = err {
                print("Error writing document: \(err)")
            } else {
                print("Document successfully written!")
            }
        }
        //Put location
    }

    func getDateTime(){
        //Get subcollection data from Firestore. Replace all placeholders.
        self.dateTime=[:]
    }
}
