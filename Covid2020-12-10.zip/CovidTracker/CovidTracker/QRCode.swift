//
//  QRCode.swift
//  CovidTracker
//
//  Created by Asrith Sreeram on 11/14/20.
//  Copyright © 2020 Asrith Sreeram. All rights reserved.
//

import Foundation
import UIKit

class QRCode{
    
    var code: UIImage
    
    init(_ image: UIImage){
        self.code=image
    }
    
    func scan() -> Location {
        return scan()
    }
 
}
