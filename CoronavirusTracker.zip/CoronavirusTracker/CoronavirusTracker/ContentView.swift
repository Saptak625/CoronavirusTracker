//
//  ContentView.swift
//  CoronavirusTracker
//
//  Created by Asrith Sreeram on 12/6/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
