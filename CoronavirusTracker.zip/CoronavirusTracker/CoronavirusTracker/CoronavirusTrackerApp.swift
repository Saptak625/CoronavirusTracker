//
//  CoronavirusTrackerApp.swift
//  CoronavirusTracker
//
//  Created by Asrith Sreeram on 12/6/20.
//

import SwiftUI

@main
struct CoronavirusTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
